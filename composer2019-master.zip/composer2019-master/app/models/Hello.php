<?php


namespace Composer\Application\models;


class Hello{
    public function diga($nome){
        return "Hello " . $nome;
    }
}