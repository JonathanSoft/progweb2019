<?php

namespace Renato\SON;


class HelloPackage
{

    public function getHello(){
        return "Hello Package";
    }

}